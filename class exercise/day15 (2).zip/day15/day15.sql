DROP DATABASE IF EXISTS TechNovaDB;
CREATE DATABASE TechNovaDB;
USE TechNovaDB;

CREATE TABLE Department (
    DeptID INT PRIMARY KEY,
    DeptName VARCHAR(50) NOT NULL UNIQUE,
    Location VARCHAR(50) NOT NULL
);


CREATE TABLE Employee (
    EmpID INT PRIMARY KEY,
    EmpName VARCHAR(100) NOT NULL,
    Gender ENUM('M','F') NOT NULL,
    DOB DATE NOT NULL,
    HireDate DATE NOT NULL,
    DeptID INT,
    FOREIGN KEY (DeptID) REFERENCES Department(DeptID)
);


CREATE TABLE Project (
    ProjectID INT PRIMARY KEY,
    ProjectName VARCHAR(100) NOT NULL,
    DeptID INT,
    StartDate DATE,
    EndDate DATE,
    FOREIGN KEY (DeptID) REFERENCES Department(DeptID)
);


CREATE TABLE Performance (
    EmpID INT,
    ProjectID INT,
    Rating DECIMAL(3,1) CHECK (Rating BETWEEN 1 AND 5),
    ReviewDate DATE,
    PRIMARY KEY (EmpID, ProjectID),
    FOREIGN KEY (EmpID) REFERENCES Employee(EmpID),
    FOREIGN KEY (ProjectID) REFERENCES Project(ProjectID)
);


CREATE TABLE Reward (
    EmpID INT,
    RewardMonth DATE,
    RewardAmount DECIMAL(10,2),
    PRIMARY KEY (EmpID, RewardMonth),
    FOREIGN KEY (EmpID) REFERENCES Employee(EmpID)
);


CREATE INDEX idx_empname ON Employee(EmpName);
CREATE INDEX idx_deptid ON Employee(DeptID);


INSERT INTO Department VALUES
(101,'IT','Bangalore'),
(102,'HR','Delhi'),
(103,'Finance','Mumbai'),
(104,'Support','Hyderabad'),
(105,'R&D','Pune');


INSERT INTO Employee VALUES
(1,'Asha','F','1990-07-12','2018-06-10',101),
(2,'Raj','M','1988-04-09','2020-03-22',102),
(3,'Neha','F','1995-01-15','2021-08-05',101),
(4,'Arjun','M','1992-11-19','2017-01-12',103),
(5,'Meera','F','1996-02-25','2022-05-30',104);


INSERT INTO Project VALUES
(1001,'Website Upgrade',101,'2024-01-01','2024-12-31'),
(1002,'Payroll System',102,'2024-02-01','2024-10-30'),
(1003,'Audit Automation',103,'2024-03-01','2024-09-15'),
(1004,'Support Portal',104,'2024-04-01','2024-11-30'),
(1005,'AI Innovation',105,'2024-05-01','2024-12-31');


INSERT INTO Performance VALUES
(1,1001,4.5,'2024-12-10'),
(2,1002,3.8,'2024-10-20'),
(3,1001,4.9,'2024-12-05'),
(4,1003,4.2,'2024-09-18'),
(5,1004,3.7,'2024-11-12');


INSERT INTO Reward VALUES
(1,'2025-01-01',5000),
(2,'2025-01-01',1500),
(3,'2025-02-01',3000),
(4,'2025-01-01',800),
(5,'2025-03-01',2500);

UPDATE Employee
SET DeptID = 105
WHERE EmpID = 2;


SET SQL_SAFE_UPDATES = 0;
DELETE FROM Reward WHERE RewardAmount < 1000;
SET SQL_SAFE_UPDATES = 1;


SELECT * FROM Employee
WHERE HireDate > '2019-01-01';

SELECT d.DeptName, AVG(p.Rating) AS AvgRating
FROM Performance p
JOIN Employee e ON p.EmpID = e.EmpID
JOIN Department d ON e.DeptID = d.DeptID
GROUP BY d.DeptName;

SELECT EmpName,
TIMESTAMPDIFF(YEAR, DOB, CURDATE()) AS Age
FROM Employee;

SELECT SUM(RewardAmount) AS TotalRewards
FROM Reward
WHERE YEAR(RewardMonth) = YEAR(CURDATE());


SELECT e.EmpName, r.RewardAmount
FROM Employee e
JOIN Reward r ON e.EmpID = r.EmpID
WHERE r.RewardAmount > 2000;


SELECT e.EmpName, d.DeptName, pr.ProjectName, p.Rating
FROM Performance p
JOIN Employee e ON p.EmpID = e.EmpID
JOIN Department d ON e.DeptID = d.DeptID
JOIN Project pr ON p.ProjectID = pr.ProjectID;

SELECT e.EmpName, d.DeptName, p.Rating
FROM Performance p
JOIN Employee e ON p.EmpID = e.EmpID
JOIN Department d ON e.DeptID = d.DeptID
WHERE p.Rating = (
    SELECT MAX(p2.Rating)
    FROM Performance p2
    JOIN Employee e2 ON p2.EmpID = e2.EmpID
    WHERE e2.DeptID = e.DeptID
);

SELECT EmpName
FROM Employee
WHERE EmpID NOT IN (SELECT EmpID FROM Reward);



START TRANSACTION;

INSERT INTO Employee VALUES
(6,'Karan','M','1998-08-14','2025-02-01',101);

INSERT INTO Performance VALUES
(6,1001,4.3,'2025-12-10');


COMMIT;


START TRANSACTION;
INSERT INTO Employee VALUES
(7,'Test','M','1999-01-01','2025-01-01',101);
ROLLBACK;


EXPLAIN
SELECT e.EmpName, d.DeptName
FROM Employee e
JOIN Department d ON e.DeptID = d.DeptID;


EXPLAIN
SELECT e.EmpName, d.DeptName
FROM Employee e
JOIN Department d ON e.DeptID = d.DeptID;



CREATE OR REPLACE VIEW EmployeePerformanceView AS
SELECT e.EmpName, d.DeptName, p.Rating
FROM Performance p
JOIN Employee e ON p.EmpID = e.EmpID
JOIN Department d ON e.DeptID = d.DeptID;

SELECT * FROM EmployeePerformanceView;



DELIMITER //

CREATE PROCEDURE GetTopPerformers(IN deptName VARCHAR(50))
BEGIN
    SELECT e.EmpName, p.Rating
    FROM Performance p
    JOIN Employee e ON p.EmpID = e.EmpID
    JOIN Department d ON e.DeptID = d.DeptID
    WHERE d.DeptName = deptName
    ORDER BY p.Rating DESC
    LIMIT 3;
END //

DELIMITER ;

CALL GetTopPerformers('IT');

