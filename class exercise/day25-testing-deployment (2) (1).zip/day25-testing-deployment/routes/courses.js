// routes/courses.js — In-memory CRUD for /api/courses

const express = require('express');
const router  = express.Router();

let courses = [
  { id: 1, name: 'React Mastery',      duration: '6 weeks' },
  { id: 2, name: 'Node.js Basics',     duration: '4 weeks' },
  { id: 3, name: 'MongoDB Essentials', duration: '3 weeks' },
];
let nextId = 4;

// GET all courses
router.get('/', (req, res) => {
  res.json({ success: true, data: courses });
});

// GET single course
router.get('/:id', (req, res) => {
  const course = courses.find(c => c.id === parseInt(req.params.id));
  if (!course) return res.status(404).json({ error: 'Course not found' });
  res.json({ success: true, data: course });
});

// POST create course
router.post('/', (req, res) => {
  const { name, duration } = req.body;
  if (!name)     return res.status(400).json({ error: 'Course name is required' });
  if (!duration) return res.status(400).json({ error: 'Course duration is required' });
  const newCourse = { id: nextId++, name, duration };
  courses.push(newCourse);
  res.status(201).json({ success: true, data: newCourse });
});

// PUT update course
router.put('/:id', (req, res) => {
  const index = courses.findIndex(c => c.id === parseInt(req.params.id));
  if (index === -1) return res.status(404).json({ error: 'Course not found' });
  courses[index] = { ...courses[index], ...req.body };
  res.json({ success: true, data: courses[index] });
});

// DELETE course
router.delete('/:id', (req, res) => {
  const index = courses.findIndex(c => c.id === parseInt(req.params.id));
  if (index === -1) return res.status(404).json({ error: 'Course not found' });
  const deleted = courses.splice(index, 1);
  res.json({ success: true, message: 'Course deleted', data: deleted[0] });
});

// Helper: reset courses (used in tests to restore clean state)
router.resetCourses = () => {
  courses = [
    { id: 1, name: 'React Mastery',      duration: '6 weeks' },
    { id: 2, name: 'Node.js Basics',     duration: '4 weeks' },
    { id: 3, name: 'MongoDB Essentials', duration: '3 weeks' },
  ];
  nextId = 4;
};

module.exports = router;
