// routes/users.js — In-memory CRUD for /api/users

const express = require('express');
const router  = express.Router();

let users = [
  { id: 1, name: 'Alice',   email: 'alice@skillsphere.com', role: 'student'    },
  { id: 2, name: 'Bob',     email: 'bob@skillsphere.com',   role: 'instructor' },
];
let nextId = 3;

// GET all users
router.get('/', (req, res) => {
  res.json({ success: true, data: users });
});

// GET single user
router.get('/:id', (req, res) => {
  const user = users.find(u => u.id === parseInt(req.params.id));
  if (!user) return res.status(404).json({ error: 'User not found' });
  res.json({ success: true, data: user });
});

// POST create user
router.post('/', (req, res) => {
  const { name, email, role } = req.body;
  if (!name)  return res.status(400).json({ error: 'Name is required' });
  if (!email) return res.status(400).json({ error: 'Email is required' });
  const newUser = { id: nextId++, name, email, role: role || 'student' };
  users.push(newUser);
  res.status(201).json({ success: true, data: newUser });
});

// DELETE user
router.delete('/:id', (req, res) => {
  const index = users.findIndex(u => u.id === parseInt(req.params.id));
  if (index === -1) return res.status(404).json({ error: 'User not found' });
  const deleted = users.splice(index, 1);
  res.json({ success: true, message: 'User deleted', data: deleted[0] });
});

// Helper: reset users (used in tests)
router.resetUsers = () => {
  users = [
    { id: 1, name: 'Alice', email: 'alice@skillsphere.com', role: 'student'    },
    { id: 2, name: 'Bob',   email: 'bob@skillsphere.com',   role: 'instructor' },
  ];
  nextId = 3;
};

module.exports = router;
