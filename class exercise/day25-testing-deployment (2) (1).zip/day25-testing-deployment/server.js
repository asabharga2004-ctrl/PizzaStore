// ─────────────────────────────────────────────────────────
// server.js — Day 25: Testing & Deployment
// SkillSphere LMS API — Production-Ready
// ─────────────────────────────────────────────────────────

const express     = require('express');
const compression = require('compression'); // Best Practice: gzip compression
const courseRoutes = require('./routes/courses');
const userRoutes   = require('./routes/users');

const app = express();

// ── Challenge 3: PORT from environment variable (Deployment best practice) ──
const PORT = process.env.PORT || 4000;

// ── Global Middleware ──
app.use(compression());        // gzip compression for performance
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// ── Challenge 3: /status route — confirms app is live ──
app.get('/status', (req, res) => {
  res.json({ message: 'App is live' });
});

// ── Root Route ──
app.get('/', (req, res) => {
  res.json({ message: 'Welcome to SkillSphere LMS API - Day 25' });
});

// ── API Routes ──
app.use('/api/courses', courseRoutes);
app.use('/api/users',   userRoutes);

// ── 404 Handler ──
app.use((req, res) => {
  res.status(404).json({ error: 'Route not found' });
});

// ── Start server only when not in test mode ──
if (require.main === module) {
  app.listen(PORT, () => {
    console.log(`✅ SkillSphere API running at http://localhost:${PORT}`);
    console.log(`🔗 Status  : http://localhost:${PORT}/status`);
    console.log(`📚 Courses : http://localhost:${PORT}/api/courses`);
    console.log(`👤 Users   : http://localhost:${PORT}/api/users`);
  });
}

// Export app for testing (SuperTest needs this)
module.exports = app;
