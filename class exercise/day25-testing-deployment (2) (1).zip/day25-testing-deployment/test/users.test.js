// ─────────────────────────────────────────────────────────
// test/users.test.js
// Challenge 2 (Average): Integration Testing with SuperTest
// Tests /api/users routes AND middleware interaction
// ─────────────────────────────────────────────────────────

const request  = require('supertest');
const { expect } = require('chai');
const app      = require('../server');
const userRouter = require('../routes/users');

// Reset user data before each test
beforeEach(() => {
  userRouter.resetUsers();
});

describe('👤 USERS API — Integration Tests (SuperTest)', () => {

  // ── GET ALL ──
  describe('GET /api/users', () => {
    it('should return all users', async () => {
      const res = await request(app).get('/api/users');
      expect(res.status).to.equal(200);
      expect(res.body.success).to.be.true;
      expect(res.body.data).to.be.an('array');
      expect(res.body.data.length).to.equal(2);
    });

    it('should return correct content-type JSON', async () => {
      const res = await request(app).get('/api/users');
      expect(res.headers['content-type']).to.include('application/json');
    });
  });

  // ── GET SINGLE ──
  describe('GET /api/users/:id', () => {
    it('should return user with id 1', async () => {
      const res = await request(app).get('/api/users/1');
      expect(res.status).to.equal(200);
      expect(res.body.data.name).to.equal('Alice');
      expect(res.body.data.role).to.equal('student');
    });

    it('should return 404 for non-existent user', async () => {
      const res = await request(app).get('/api/users/999');
      expect(res.status).to.equal(404);
      expect(res.body.error).to.equal('User not found');
    });
  });

  // ── POST ──
  describe('POST /api/users', () => {
    it('should create a new user successfully', async () => {
      const res = await request(app)
        .post('/api/users')
        .send({ name: 'Charlie', email: 'charlie@skillsphere.com', role: 'student' });
      expect(res.status).to.equal(201);
      expect(res.body.success).to.be.true;
      expect(res.body.data.name).to.equal('Charlie');
    });

    it('should return 400 if name is missing', async () => {
      const res = await request(app)
        .post('/api/users')
        .send({ email: 'test@test.com' });
      expect(res.status).to.equal(400);
      expect(res.body.error).to.equal('Name is required');
    });

    it('should return 400 if email is missing', async () => {
      const res = await request(app)
        .post('/api/users')
        .send({ name: 'Dave' });
      expect(res.status).to.equal(400);
      expect(res.body.error).to.equal('Email is required');
    });

    it('should default role to student if not provided', async () => {
      const res = await request(app)
        .post('/api/users')
        .send({ name: 'Eve', email: 'eve@skillsphere.com' });
      expect(res.status).to.equal(201);
      expect(res.body.data.role).to.equal('student');
    });
  });

  // ── DELETE ──
  describe('DELETE /api/users/:id', () => {
    it('should delete an existing user', async () => {
      const res = await request(app).delete('/api/users/1');
      expect(res.status).to.equal(200);
      expect(res.body.message).to.equal('User deleted');
    });

    it('should return 404 for non-existent user', async () => {
      const res = await request(app).delete('/api/users/999');
      expect(res.status).to.equal(404);
    });
  });

  // ── STATUS ROUTE (Deployment check) ──
  describe('GET /status', () => {
    it('should confirm app is live', async () => {
      const res = await request(app).get('/status');
      expect(res.status).to.equal(200);
      expect(res.body.message).to.equal('App is live');
    });
  });

});
