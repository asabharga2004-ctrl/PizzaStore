// ─────────────────────────────────────────────────────────
// test/courses.test.js
// Challenge 1 (Easy): Unit Testing with Mocha + Chai
// Tests all /api/courses routes
// ─────────────────────────────────────────────────────────

const request  = require('supertest');
const { expect } = require('chai');
const app      = require('../server');
const courseRouter = require('../routes/courses');

// Reset course data before each test for clean state
beforeEach(() => {
  courseRouter.resetCourses();
});

describe('📚 COURSES API — Unit Tests', () => {

  // ── GET ALL ──
  describe('GET /api/courses', () => {
    it('should return all courses with success: true', async () => {
      const res = await request(app).get('/api/courses');
      expect(res.status).to.equal(200);
      expect(res.body.success).to.be.true;
      expect(res.body.data).to.be.an('array');
      expect(res.body.data.length).to.equal(3);
    });
  });

  // ── GET SINGLE ──
  describe('GET /api/courses/:id', () => {
    it('should return a single course by ID', async () => {
      const res = await request(app).get('/api/courses/1');
      expect(res.status).to.equal(200);
      expect(res.body.success).to.be.true;
      expect(res.body.data.name).to.equal('React Mastery');
    });

    it('should return 404 for non-existent course', async () => {
      const res = await request(app).get('/api/courses/999');
      expect(res.status).to.equal(404);
      expect(res.body.error).to.equal('Course not found');
    });
  });

  // ── POST ──
  describe('POST /api/courses', () => {
    it('should create a new course', async () => {
      const res = await request(app)
        .post('/api/courses')
        .send({ name: 'Vue.js Basics', duration: '5 weeks' });
      expect(res.status).to.equal(201);
      expect(res.body.success).to.be.true;
      expect(res.body.data.name).to.equal('Vue.js Basics');
    });

    it('should return 400 if name is missing', async () => {
      const res = await request(app)
        .post('/api/courses')
        .send({ duration: '3 weeks' });
      expect(res.status).to.equal(400);
      expect(res.body.error).to.equal('Course name is required');
    });

    it('should return 400 if duration is missing', async () => {
      const res = await request(app)
        .post('/api/courses')
        .send({ name: 'Angular Pro' });
      expect(res.status).to.equal(400);
      expect(res.body.error).to.equal('Course duration is required');
    });
  });

  // ── PUT ──
  describe('PUT /api/courses/:id', () => {
    it('should update an existing course', async () => {
      const res = await request(app)
        .put('/api/courses/1')
        .send({ duration: '8 weeks' });
      expect(res.status).to.equal(200);
      expect(res.body.data.duration).to.equal('8 weeks');
    });

    it('should return 404 for non-existent course', async () => {
      const res = await request(app)
        .put('/api/courses/999')
        .send({ name: 'Ghost Course' });
      expect(res.status).to.equal(404);
    });
  });

  // ── DELETE ──
  describe('DELETE /api/courses/:id', () => {
    it('should delete an existing course', async () => {
      const res = await request(app).delete('/api/courses/1');
      expect(res.status).to.equal(200);
      expect(res.body.message).to.equal('Course deleted');
    });

    it('should return 404 for non-existent course', async () => {
      const res = await request(app).delete('/api/courses/999');
      expect(res.status).to.equal(404);
    });
  });

});
