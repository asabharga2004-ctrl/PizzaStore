// ─────────────────────────────────────────────────────────
// Challenge 3 (Difficult): Sequelize ORM
// One-to-Many: Instructor → Courses
// Queries all courses by an instructor
// ─────────────────────────────────────────────────────────

require('dotenv').config();
const { Sequelize } = require('sequelize');

// ── Connect to MySQL via Sequelize ──
const sequelize = new Sequelize(
  process.env.DB_NAME     || 'skillsphere_seq',
  process.env.DB_USER     || 'root',
  process.env.DB_PASSWORD || '',
  {
    host   : process.env.DB_HOST || 'localhost',
    port   : process.env.DB_PORT || 3306,
    dialect: 'mysql',
    logging: false, // disable SQL logs for clean output
  }
);

// ── Load models ──
const Instructor = require('./models/Instructor')(sequelize);
const Course     = require('./models/Course')(sequelize);

// ── Define One-to-Many Relationship ──
// One Instructor → Many Courses
Instructor.hasMany(Course,     { foreignKey: 'instructorId', as: 'courses'    });
Course.belongsTo(Instructor,   { foreignKey: 'instructorId', as: 'instructor' });

async function main() {
  try {
    console.log('🔌 Connecting to MySQL via Sequelize...');
    await sequelize.authenticate();
    console.log('✅ Sequelize connected successfully!\n');

    // Sync models — creates tables if not exist
    await sequelize.sync({ force: true });
    console.log('📋 Tables synced (instructors, courses)\n');

    // Step 1: Create Instructors
    const inst1 = await Instructor.create({ name: 'Dr. Sarah',  email: 'sarah@skillsphere.com'  });
    const inst2 = await Instructor.create({ name: 'Prof. John', email: 'john@skillsphere.com'   });
    console.log('👨‍🏫 Instructors created:');
    console.log(`   ➜ ${inst1.name} (ID: ${inst1.id})`);
    console.log(`   ➜ ${inst2.name} (ID: ${inst2.id})\n`);

    // Step 2: Create Courses linked to Instructors
    await Course.bulkCreate([
      { name: 'React Mastery',       duration: '6 weeks', instructorId: inst1.id },
      { name: 'Node.js Advanced',    duration: '5 weeks', instructorId: inst1.id },
      { name: 'MongoDB Essentials',  duration: '3 weeks', instructorId: inst2.id },
      { name: 'Vue.js Fundamentals', duration: '4 weeks', instructorId: inst2.id },
    ]);
    console.log('📚 Courses created and linked to instructors\n');

    // Step 3: Query all courses by each instructor (One-to-Many)
    const instructors = await Instructor.findAll({
      include: [{ model: Course, as: 'courses' }],
    });

    console.log('📊 Courses grouped by Instructor:');
    instructors.forEach(inst => {
      console.log(`\n   👨‍🏫 ${inst.name} teaches:`);
      inst.courses.forEach(c => {
        console.log(`      ➜ ${c.name} (${c.duration})`);
      });
    });

    console.log('\n✅ One-to-Many relationship working! Instructor → Courses');

  } catch (err) {
    console.error('❌ Sequelize Error:', err.message);
  } finally {
    await sequelize.close();
    console.log('\n🔒 Sequelize connection closed.');
  }
}

main();
