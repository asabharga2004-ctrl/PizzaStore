// models/Course.js — Sequelize Course model
const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const Course = sequelize.define('Course', {
    id: {
      type         : DataTypes.INTEGER,
      primaryKey   : true,
      autoIncrement: true,
    },
    name        : { type: DataTypes.STRING,  allowNull: false },
    duration    : { type: DataTypes.STRING,  allowNull: false },
    instructorId: { type: DataTypes.INTEGER, allowNull: false },
  }, { tableName: 'courses', timestamps: true });

  return Course;
};
