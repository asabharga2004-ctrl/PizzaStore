// models/Instructor.js — Sequelize Instructor model
const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const Instructor = sequelize.define('Instructor', {
    id: {
      type         : DataTypes.INTEGER,
      primaryKey   : true,
      autoIncrement: true,
    },
    name : { type: DataTypes.STRING, allowNull: false },
    email: { type: DataTypes.STRING, allowNull: false, unique: true },
  }, { tableName: 'instructors', timestamps: true });

  return Instructor;
};
