// ─────────────────────────────────────────────────────────
// Challenge 1 (Easy): MySQL Integration
// Connects to MySQL, creates courses table, inserts data
// ─────────────────────────────────────────────────────────

require('dotenv').config();
const mysql = require('mysql2');

// ── Create connection using .env credentials ──
const connection = mysql.createConnection({
  host    : process.env.DB_HOST     || 'localhost',
  user    : process.env.DB_USER     || 'root',
  password: process.env.DB_PASSWORD || '',
  port    : process.env.DB_PORT     || 3306,
});

console.log('🔌 Connecting to MySQL...');

connection.connect((err) => {
  if (err) {
    console.error('❌ MySQL Connection Error:', err.message);
    process.exit(1);
  }
  console.log('✅ Connected to MySQL successfully!\n');

  // Step 1: Create database if not exists
  connection.query(
    `CREATE DATABASE IF NOT EXISTS ${process.env.DB_NAME || 'skillsphere'}`,
    (err) => {
      if (err) return console.error('❌ Create DB Error:', err.message);
      console.log(`📦 Database '${process.env.DB_NAME || 'skillsphere'}' ready`);

      // Step 2: Use the database
      connection.query(
        `USE ${process.env.DB_NAME || 'skillsphere'}`,
        (err) => {
          if (err) return console.error('❌ USE DB Error:', err.message);

          // Step 3: Create courses table
          const createTable = `
            CREATE TABLE IF NOT EXISTS courses (
              id       INT AUTO_INCREMENT PRIMARY KEY,
              name     VARCHAR(255) NOT NULL,
              duration VARCHAR(100) NOT NULL,
              created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
          `;
          connection.query(createTable, (err) => {
            if (err) return console.error('❌ Create Table Error:', err.message);
            console.log('📋 Table \'courses\' ready\n');

            // Step 4: Insert course data
            const courses = [
              ['React Mastery',       '6 weeks'],
              ['Node.js Basics',      '4 weeks'],
              ['MongoDB Essentials',  '3 weeks'],
            ];

            const insertSQL = 'INSERT INTO courses (name, duration) VALUES ?';
            connection.query(insertSQL, [courses], (err, result) => {
              if (err) return console.error('❌ Insert Error:', err.message);
              console.log('✅ INSERT INTO courses successful!');
              console.log(`   ➜ ${result.affectedRows} rows inserted`);
              console.log(`   ➜ First inserted ID: ${result.insertId}\n`);

              // Step 5: Fetch and display all courses
              connection.query('SELECT * FROM courses', (err, rows) => {
                if (err) return console.error('❌ Select Error:', err.message);
                console.log('📚 All Courses in MySQL:');
                console.table(rows);
                connection.end(() => {
                  console.log('🔒 MySQL connection closed.');
                });
              });
            });
          });
        }
      );
    }
  );
});
