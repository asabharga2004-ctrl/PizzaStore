const mongoose = require('mongoose');

const enrollmentSchema = new mongoose.Schema({
  userId    : { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  courseName: { type: String, required: true },
  enrolledAt: { type: Date, default: Date.now },
  status    : { type: String, enum: ['active', 'completed', 'dropped'], default: 'active' },
}, { timestamps: true });

module.exports = mongoose.model('Enrollment', enrollmentSchema);
