// ─────────────────────────────────────────────────────────
// Challenge 2 (Average): MongoDB Integration with Mongoose
// Models: User and Enrollment
// ─────────────────────────────────────────────────────────

require('dotenv').config();
const mongoose   = require('mongoose');
const User       = require('./models/User');
const Enrollment = require('./models/Enrollment');

const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/skillsphere';

async function main() {
  try {
    console.log('🔌 Connecting to MongoDB...');
    await mongoose.connect(MONGO_URI);
    console.log('✅ Connected to MongoDB successfully!\n');

    // Clear old data for clean demo run
    await User.deleteMany({});
    await Enrollment.deleteMany({});

    // Step 1: Create Users
    const users = await User.insertMany([
      { name: 'Alice',   email: 'alice@skillsphere.com',   role: 'student'    },
      { name: 'Bob',     email: 'bob@skillsphere.com',     role: 'student'    },
      { name: 'Charlie', email: 'charlie@skillsphere.com', role: 'instructor' },
    ]);
    console.log('👤 Users inserted:');
    users.forEach(u => console.log(`   ➜ ${u.name} (${u.role})`));

    // Step 2: Create Enrollments
    const enrollments = await Enrollment.insertMany([
      { userId: users[0]._id, courseName: 'React Mastery',      status: 'active'    },
      { userId: users[0]._id, courseName: 'Node.js Basics',     status: 'completed' },
      { userId: users[1]._id, courseName: 'MongoDB Essentials', status: 'active'    },
    ]);
    console.log('\n📋 Enrollments inserted:');
    enrollments.forEach(e => console.log(`   ➜ Course: ${e.courseName} | Status: ${e.status}`));

    // Step 3: Fetch enrollments WITH user details (populate)
    console.log('\n📊 Fetching Enrollment Details with User Info:');
    const details = await Enrollment.find().populate('userId', 'name email role');
    details.forEach(e => {
      console.log(`\n   Student  : ${e.userId.name} (${e.userId.email})`);
      console.log(`   Course   : ${e.courseName}`);
      console.log(`   Status   : ${e.status}`);
      console.log(`   Enrolled : ${e.enrolledAt.toDateString()}`);
    });

    console.log('\n✅ Successfully fetches and displays enrollment details!');

  } catch (err) {
    console.error('❌ Error:', err.message);
  } finally {
    await mongoose.disconnect();
    console.log('\n🔒 MongoDB connection closed.');
  }
}

main();
