BookStore API — Express.js Day 19
A REST API built with Express.js covering routing, middleware, CRUD, and error handling.

Project Structure
bookstore-api/
├── server.js
├── routes/
│   └── books.js
├── package.json
└── README.md

Setup:
bash npm install
node server.js
Server runs at: http://localhost:4000
 
Routes
MethodURLDescriptionGET/Welcome messageGET/statusServer statusGET/products?name=LaptopSearch productGET/booksGet all booksGET/books/:idGet book by IDPOST/booksAdd new bookPUT/books/:idUpdate bookDELETE/books/:idDelete book

POST / PUT Body Format
json{
  "title": "Harry Potter",
  "author": "J.K. Rowling"
}

Error Responses
StatusMeaning400Validation failed (missing title or author)404Book not found or route not found500Internal server error