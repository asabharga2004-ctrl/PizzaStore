
const express = require('express');
const cors = require('cors');          
const bookRouter = require('./routes/books'); 
const app = express();
const PORT = 4000;                     

app.use(express.json());               
app.use(cors());                       


app.use((req, _res, next) => {
  const timestamp = new Date().toISOString(); 
  console.log(`[${timestamp}] [${req.method}] ${req.url}`);
  next(); 
});


app.get('/', (_req, res) => {
  res.send('Welcome to Express Server');
});


app.get('/status', (_req, res) => {
  res.json({ server: 'running', uptime: 'OK' });
});


app.get('/products', (req, res) => {
  const { name } = req.query; 

  if (name) {
    
    return res.json({ query: name, message: `Searching for product: ${name}` });
  }

  res.json({ message: 'Please provide a product name' });
});


app.use('/books', bookRouter);


app.use((_req, res) => {
  res.status(404).json({ error: 'Route not found' });
});


app.use((err, _req, res, _next) => {
  console.error(`[ERROR] ${err.message}`);
  res.status(500).json({ error: 'Internal Server Error' });
});


app.listen(PORT, () => {
  console.log(`✅  Server running at http://localhost:${PORT}`);
  console.log('');
  console.log('Available routes:');
  console.log(`  GET  http://localhost:${PORT}/`);
  console.log(`  GET  http://localhost:${PORT}/status`);
  console.log(`  GET  http://localhost:${PORT}/products?name=Laptop`);
  console.log(`  GET  http://localhost:${PORT}/books`);
  console.log(`  GET  http://localhost:${PORT}/books/:id`);
  console.log(`  POST http://localhost:${PORT}/books`);
  console.log(`  PUT  http://localhost:${PORT}/books/:id`);
  console.log(`  DEL  http://localhost:${PORT}/books/:id`);
});
