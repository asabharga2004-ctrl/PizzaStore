
const express = require('express');
const router = express.Router();
const { body, validationResult } = require('express-validator');


let books = [
  { id: 1, title: '1984', author: 'Orwell' },
  { id: 2, title: 'The Alchemist', author: 'Coelho' },
];
let nextId = 3; 


router.get('/', (req, res) => {
  res.json(books);
});


router.get('/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const book = books.find((b) => b.id === id);

  if (!book) {
    return res.status(404).json({ error: `Book with id ${id} not found` });
  }

  res.json(book);
});


router.post(
  '/',
  [
    
    body('title')
      .notEmpty()
      .withMessage('Title is required')
      .isString()
      .withMessage('Title must be a string'),
    body('author')
      .notEmpty()
      .withMessage('Author is required')
      .isString()
      .withMessage('Author must be a string'),
  ],
  (req, res) => {

    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { title, author } = req.body;
    const newBook = { id: nextId++, title, author };
    books.push(newBook);
    res.status(201).json({ message: 'Book added successfully', book: newBook });
  }
);


router.put(
  '/:id',
  [
    body('title').optional().notEmpty().withMessage('Title cannot be empty'),
    body('author').optional().notEmpty().withMessage('Author cannot be empty'),
  ],
  (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const id = parseInt(req.params.id);
    const index = books.findIndex((b) => b.id === id);

    if (index === -1) {
      return res.status(404).json({ error: `Book with id ${id} not found` });
    }

    books[index] = { ...books[index], ...req.body, id }; 
    res.json({ message: 'Book updated successfully', book: books[index] });
  }
);


router.delete('/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const index = books.findIndex((b) => b.id === id);

  if (index === -1) {
    return res.status(404).json({ error: `Book with id ${id} not found` });
  }

  const deleted = books.splice(index, 1)[0];
  res.json({ message: 'Book deleted successfully', book: deleted });
});

module.exports = router;
