const fs = require("fs").promises;

async function runExample() {
    try {

        const message = "Node.js is awesome!";

        await fs.writeFile("feedback.txt", message);

        console.log("Data written successfully.");
        console.log("Reading file...");

        const data = await fs.readFile("feedback.txt", "utf8");

        console.log(data);

    } catch (error) {
        console.log(error);
    }
}

runExample();