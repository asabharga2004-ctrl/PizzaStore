const http = require("http");
const fs = require("fs");

const server = http.createServer((req, res) => {

    if (req.url === "/") {
        res.writeHead(200, {"Content-Type": "text/plain"});
        res.end("Hello from Node.js Server");
    }

    else if (req.url === "/about") {

        fs.readFile("about.html", (err, data) => {

            res.writeHead(200, {"Content-Type": "text/html"});
            res.end(data);

        });

    }

});

server.listen(3000, () => {
    console.log("Server running at http://localhost:3000");
});