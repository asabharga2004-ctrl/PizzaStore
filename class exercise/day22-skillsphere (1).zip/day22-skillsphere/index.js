require('dotenv').config();
const express    = require('express');
const mongoose   = require('mongoose');
const session    = require('express-session');
const MongoStore = require('connect-mongo');
const passport   = require('./config/passport');
const path       = require('path');

const User                    = require('./models/User');
const { isAuthenticated, isAdmin } = require('./middleware/auth');

const app  = express();
const PORT = process.env.PORT || 3000;

// ─────────────────────────────────────────────────────────────
// Database Connection (Challenge 2)
// ─────────────────────────────────────────────────────────────
mongoose
  .connect(process.env.MONGO_URI)
  .then(() => console.log('✅ MongoDB connected:', process.env.MONGO_URI))
  .catch((err) => console.error('❌ MongoDB connection error:', err.message));

// ─────────────────────────────────────────────────────────────
// View Engine — EJS
// ─────────────────────────────────────────────────────────────
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// ─────────────────────────────────────────────────────────────
// Built-in Middleware
// ─────────────────────────────────────────────────────────────
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// ─────────────────────────────────────────────────────────────
// Logging Middleware
// ─────────────────────────────────────────────────────────────
app.use((req, res, next) => {
  console.log(`[${req.method}] ${req.url} at ${new Date().toISOString()}`);
  next();
});

// ─────────────────────────────────────────────────────────────
// Session & Passport (Challenge 3)
// Best Practice: Store secrets in .env
// ─────────────────────────────────────────────────────────────
app.use(
  session({
    secret: process.env.SESSION_SECRET,
    resave: false,
    saveUninitialized: false,
    store: MongoStore.create({ mongoUrl: process.env.MONGO_URI }),
    cookie: { maxAge: 1000 * 60 * 60 }, // 1 hour
  })
);
app.use(passport.initialize());
app.use(passport.session());

// ─────────────────────────────────────────────────────────────
// ROOT
// ─────────────────────────────────────────────────────────────
app.get('/', (req, res) => {
  res.json({
    message: 'SkillSphere LMS API — Day 22',
    endpoints: {
      'GET  /register'  : 'Show registration form (HTML)',
      'POST /register'  : 'Submit registration',
      'GET  /login'     : 'Show login form (HTML)',
      'POST /login'     : 'Submit login',
      'GET  /logout'    : 'Logout',
      'GET  /admin'     : 'Admin only (RBAC)',
      'GET  /dashboard' : 'Logged-in users only',
    },
  });
});

// ─────────────────────────────────────────────────────────────
// Challenge 1: Form Handling — Registration
// ─────────────────────────────────────────────────────────────

// Show registration form
app.get('/register', (req, res) => {
  res.render('register', { error: null, success: null });
});

// Handle form submission
app.post('/register', async (req, res) => {
  const { name, email, password, role } = req.body;

  if (!name || !email || !password) {
    return res.render('register', {
      error: 'All fields are required',
      success: null,
    });
  }

  try {
    const existing = await User.findOne({ email });
    if (existing) {
      return res.render('register', {
        error: 'Email already registered',
        success: null,
      });
    }

    // Challenge 2: Save to MongoDB (password auto-hashed via pre-save hook)
    const user = new User({ name, email, password, role: role || 'student' });
    await user.save();

    // Console log confirmation (Challenge 2 expected outcome)
    console.log(`✅ User saved to MongoDB: ${user.name} (${user.email}) — role: ${user.role}`);

    res.render('register', {
      error: null,
      success: `Registration successful for ${name}`,  // Challenge 1 expected outcome
    });
  } catch (err) {
    res.render('register', { error: err.message, success: null });
  }
});

// ─────────────────────────────────────────────────────────────
// Challenge 3: Authentication — Login with Passport.js
// ─────────────────────────────────────────────────────────────

// Show login form
app.get('/login', (req, res) => {
  res.render('login', { error: null });
});

// Handle login
app.post('/login', (req, res, next) => {
  passport.authenticate('local', (err, user, info) => {
    if (err) return next(err);
    if (!user) {
      return res.render('login', { error: info.message || 'Login failed' });
    }
    req.logIn(user, (err) => {
      if (err) return next(err);
      console.log(`✅ User logged in: ${user.name} — role: ${user.role}`);
      return res.redirect('/dashboard');
    });
  })(req, res, next);
});

// Logout
app.get('/logout', (req, res) => {
  req.logout(() => {
    res.redirect('/login');
  });
});

// ─────────────────────────────────────────────────────────────
// Challenge 3: RBAC — Protected Routes
// ─────────────────────────────────────────────────────────────

// Dashboard — any logged-in user
app.get('/dashboard', isAuthenticated, (req, res) => {
  res.render('dashboard', { user: req.user });
});

// Admin route — admin role only
app.get('/admin', isAdmin, (req, res) => {
  res.render('admin', { user: req.user });
});

// ─────────────────────────────────────────────────────────────
// Start Server
// ─────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`\n🚀 SkillSphere LMS running at http://localhost:${PORT}`);
  console.log(`📝 Register : http://localhost:${PORT}/register`);
  console.log(`🔐 Login    : http://localhost:${PORT}/login`);
  console.log(`🛡️  Admin    : http://localhost:${PORT}/admin\n`);
});
