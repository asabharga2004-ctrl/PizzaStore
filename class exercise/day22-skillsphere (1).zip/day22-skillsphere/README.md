# Day 22 — Forms, Database & Authentication (SkillSphere LMS)

## Project Structure

```
day22-skillsphere/
├── index.js                  ← Main Express app
├── models/
│   └── User.js               ← Mongoose User model
├── config/
│   └── passport.js           ← Passport.js local strategy
├── middleware/
│   └── auth.js               ← isAuthenticated, isAdmin (RBAC)
├── views/
│   ├── register.ejs          ← Registration form
│   ├── login.ejs             ← Login form
│   ├── dashboard.ejs         ← User dashboard
│   └── admin.ejs             ← Admin only page
├── .env                      ← Secrets (DB URI, session secret)
├── .env.example              ← Template for .env
└── package.json
```

---

## ▶️ Commands to Run

### Step 1 — Install MongoDB (if not installed)
Download from: https://www.mongodb.com/try/download/community
After install, start MongoDB:
```bash
# Windows (run as Admin in CMD)
net start MongoDB

# OR manually start
mongod
```

### Step 2 — Install dependencies
```bash
npm install
```

### Step 3 — Start the server
```bash
node index.js
```

---

## 🧪 How to Test Each Challenge

### Challenge 1 — Form Handling
```
Open browser → http://localhost:3000/register
Fill form → name: John Doe, email, password, role: student
Click Register
Expected: "Registration successful for John Doe"
```

### Challenge 2 — MongoDB Integration
```
After registering, check terminal:
✅ User saved to MongoDB: John Doe (john@example.com) — role: student
```

### Challenge 3 — Authentication + RBAC

**Register an admin:**
```
http://localhost:3000/register
→ name: Admin User, email: admin@test.com, password: admin123, role: Admin
```

**Login as admin:**
```
http://localhost:3000/login
→ email: admin@test.com, password: admin123
→ Redirects to /dashboard
```

**Access admin route:**
```
http://localhost:3000/admin
→ Admin sees: "Welcome, Admin!"
→ Non-admin sees: "Access Denied. Admins only."
→ Not logged in: "Access Denied. Please log in first."
```

---

## 📸 Screenshots Needed

| # | What | URL |
|---|------|-----|
| 1 | Registration form | /register |
| 2 | Success message after register | /register (after submit) |
| 3 | Terminal showing MongoDB save log | Terminal |
| 4 | Login form | /login |
| 5 | Admin panel | /admin |
| 6 | Access Denied (logout then visit /admin) | /admin |
