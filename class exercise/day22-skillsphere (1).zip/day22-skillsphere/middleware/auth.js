// Middleware: Check if user is logged in
const isAuthenticated = (req, res, next) => {
  if (req.isAuthenticated()) return next();
  res.status(401).json({ message: 'Access Denied. Please log in first.' });
};

// Middleware: Check if user has admin role (RBAC)
const isAdmin = (req, res, next) => {
  if (req.isAuthenticated() && req.user.role === 'admin') return next();
  res.status(403).json({ message: 'Access Denied. Admins only.' });
};

module.exports = { isAuthenticated, isAdmin };
