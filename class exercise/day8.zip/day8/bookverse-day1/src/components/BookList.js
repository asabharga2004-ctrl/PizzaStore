import React, { useState } from "react";
import BookCard from "./BookCard";

function BookList() {
  const [viewMode, setViewMode] = useState("grid");
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedBook, setSelectedBook] = useState(null);
  const [message, setMessage] = useState("");

  const books = [
    { id: 1, title: "Harry Potter", author: "J.K. Rowling", price: 499 },
    { id: 2, title: "The Hobbit", author: "J.R.R. Tolkien", price: 399 },
    { id: 3, title: "1984", author: "George Orwell", price: 299 },
    { id: 4, title: "Atomic Habits", author: "James Clear", price: 599 },
  ];

  const filteredBooks = books.filter(book =>
    book.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleBuy = () => {
    setMessage(`✅ You have successfully bought "${selectedBook.title}"`);
  };

  return (
    <div style={{ padding: "20px" }}>
      
      {/* Search */}
      <input
        type="text"
        placeholder="Search books..."
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
        style={{ padding: "8px", marginRight: "10px" }}
      />

      {/* View Buttons */}
      <button onClick={() => setViewMode("grid")}>Grid View</button>
      <button onClick={() => setViewMode("list")} style={{ marginLeft: "10px" }}>
        List View
      </button>

      {/* Books */}
      <div className={viewMode === "grid" ? "grid" : "list"}>
        {filteredBooks.map(book => (
          <div key={book.id} onClick={() => {
              setSelectedBook(book);
              setMessage("");
            }}>
            <BookCard
              title={book.title}
              author={book.author}
              price={book.price}
              viewMode={viewMode}
            />
          </div>
        ))}
      </div>

      {/* Selected Book Section */}
      {selectedBook && (
        <div style={{ marginTop: "30px", padding: "20px", background: "white" }}>
          <h2>Selected Book</h2>
          <p><strong>Title:</strong> {selectedBook.title}</p>
          <p><strong>Author:</strong> {selectedBook.author}</p>
          <p><strong>Price:</strong> ₹{selectedBook.price}</p>

          <button onClick={handleBuy} style={{ padding: "10px", marginTop: "10px" }}>
            Buy Now
          </button>

          {message && <p style={{ color: "green", marginTop: "10px" }}>{message}</p>}
        </div>
      )}

    </div>
  );
}

export default BookList;