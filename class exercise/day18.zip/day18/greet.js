const moment = require("moment");

// Get name from command line
const name = process.argv[2];

if (!name) {
    console.log("Please enter your name");
    console.log("Example: node greet.js John");
    process.exit();
}

// Format date and time
const dateTime = moment().format("ddd MMM D YYYY, hh:mm A");

// Print greeting
console.log(`Hello, ${name}! Today is ${dateTime}`);