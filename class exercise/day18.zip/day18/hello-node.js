console.log("Node Version:", process.version);

console.log("File Name:", __filename);

console.log("Directory:", __dirname);

let count = 0;

const timer = setInterval(() => {
  count++;
  console.log("Welcome to Node.js!", count);
}, 3000);

setTimeout(() => {
  clearInterval(timer);
  console.log("Stopped after 10 seconds");
}, 10000);