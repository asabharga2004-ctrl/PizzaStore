import React, { Component, createRef } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "./App.css";
import BookList from "./components/BookList";

class App extends Component {
  constructor(props) {
    super(props);
    this.searchInput = createRef();
  }

  focusSearch = () => {
    this.searchInput.current.focus();
  };

  render() {
    return (
      <div className="container mt-4">
        <h1 className="text-center mb-4">📚 BookVerse</h1>

        <div className="d-flex mb-4">
          <input
            type="text"
            ref={this.searchInput}
            className="form-control me-2"
            placeholder="Search book..."
          />
          <button className="btn btn-primary" onClick={this.focusSearch}>
            Focus Search
          </button>
        </div>

        <BookList />
      </div>
    );
  }
}

export default App;