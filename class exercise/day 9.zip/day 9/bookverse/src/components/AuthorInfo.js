import React, { Component } from "react";

class AuthorInfo extends Component {
  componentDidMount() {
    console.log("AuthorInfo component mounted.");
  }

  render() {
    const { author } = this.props;

    return (
      <div className="card p-3 shadow">
        <h4>Author Details</h4>
        <p><strong>Name:</strong> {author.author}</p>
        <p><strong>Bio:</strong> {author.bio}</p>

        <h5>Top 3 Books:</h5>
        <ul>
          {author.topBooks.map((book, index) => (
            <li key={index}>{book}</li>
          ))}
        </ul>
      </div>
    );
  }
}

export default AuthorInfo;