import React, { Component } from "react";
import PropTypes from "prop-types";

class BookCard extends Component {
  render() {
    const { book, onSelect } = this.props;

    return (
      <div className="card mb-3 shadow">
        <div className="card-body">
          <h5 className="card-title">{book.title}</h5>
          <p><strong>Author:</strong> {book.author}</p>
          <button
            className="btn btn-success"
            onClick={() => onSelect(book)}
          >
            View Author Details
          </button>
        </div>
      </div>
    );
  }
}

BookCard.propTypes = {
  book: PropTypes.object.isRequired,
  onSelect: PropTypes.func.isRequired
};

export default BookCard;