import React, { Component } from "react";
import BookCard from "./BookCard";
import AuthorInfo from "./AuthorInfo";

class BookList extends Component {
  state = {
    selectedBook: null
  };

  books = [
    {
      id: 1,
      title: "1984",
      author: "George Orwell",
      bio: "English novelist famous for dystopian works.",
      topBooks: ["Animal Farm", "Homage to Catalonia", "Down and Out in Paris"]
    },
    {
      id: 2,
      title: "Harry Potter",
      author: "J.K. Rowling",
      bio: "British author known for fantasy novels.",
      topBooks: ["Fantastic Beasts", "The Casual Vacancy", "Cormoran Strike"]
    },
    {
      id: 3,
      title: "The Great Gatsby",
      author: "F. Scott Fitzgerald",
      bio: "American novelist of the Jazz Age.",
      topBooks: ["Tender Is the Night", "This Side of Paradise", "The Beautiful and Damned"]
    }
  ];

  componentDidMount() {
    console.log("Book data loaded successfully.");
  }

  selectBook = (book) => {
    this.setState({ selectedBook: book });
  };

  render() {
    return (
      <div className="row">
        <div className="col-md-6">
          {this.books.map((book) => (
            <BookCard
              key={book.id}
              book={book}
              onSelect={this.selectBook}
            />
          ))}
        </div>

        <div className="col-md-6">
          {this.state.selectedBook && (
            <AuthorInfo author={this.state.selectedBook} />
          )}
        </div>
      </div>
    );
  }
}

export default BookList;