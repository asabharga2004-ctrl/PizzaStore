

const express   = require('express');
const http      = require('http');
const { Server } = require('socket.io');
const multer    = require('multer');
const path      = require('path');
const fs        = require('fs');

const app    = express();
const server = http.createServer(app);   
const io     = new Server(server);       

const PORT = 4000;


const uploadsDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir);


app.use(express.json());
app.use(express.urlencoded({ extended: true }));


const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    
    const sanitized = file.originalname.replace(/\s+/g, '_');
    cb(null, sanitized);
  },
});


const fileFilter = (req, file, cb) => {
  if (file.mimetype === 'application/pdf') {
    cb(null, true);
  } else {
    cb(new Error('Only PDF files are allowed!'), false);
  }
};

const upload = multer({ storage, fileFilter });


app.post('/upload', upload.single('file'), (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: 'No file uploaded' });
  }
  res.json({ message: `File uploaded successfully: ${req.file.filename}` });
});


app.use((err, req, res, next) => {
  if (err instanceof multer.MulterError || err.message) {
    return res.status(400).json({ error: err.message });
  }
  next(err);
});


app.use('/materials', express.static(path.join(__dirname, 'uploads')));


app.use(express.static(path.join(__dirname, 'public')));

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});


io.on('connection', (socket) => {
  console.log(`✅ User connected: ${socket.id}`);

 
  socket.broadcast.emit('chat-message', {
    user: 'System',
    text: 'A new user has joined the chat!',
  });

  
  socket.on('chat-message', (data) => {
    console.log(`📨 Message from ${data.user}: ${data.text}`);
   
    io.emit('chat-message', data);
  });

  // Handle disconnect
  socket.on('disconnect', () => {
    console.log(`❌ User disconnected: ${socket.id}`);
    io.emit('chat-message', {
      user: 'System',
      text: 'A user has left the chat.',
    });
  });
});

// ── Start Server ──
server.listen(PORT, () => {
  console.log(`🚀 Server running at http://localhost:${PORT}`);
  console.log(`📤 Upload endpoint : POST http://localhost:${PORT}/upload`);
  console.log(`📥 Materials folder: http://localhost:${PORT}/materials/<filename>`);
  console.log(`💬 Live Chat UI    : http://localhost:${PORT}/`);
});
