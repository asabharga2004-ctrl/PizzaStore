const App = (function () {

    const postsContainer = document.getElementById("posts");
    const todosContainer = document.getElementById("todos");

    const POSTS_URL = "https://jsonplaceholder.typicode.com/posts";
    const TODOS_URL = "https://jsonplaceholder.typicode.com/todos";

    async function fetchData(url) {
        try {
            const response = await fetch(url);

            if (!response.ok) {
                throw new Error(`HTTP Error! Status: ${response.status}`);
            }

            const data = await response.json();

            if (!Array.isArray(data)) {
                throw new Error("Unexpected data format received.");
            }

            return data;

        } catch (error) {
            throw error;
        }
    }

    async function loadPosts() {
        try {
            const posts = await fetchData(POSTS_URL);

            posts.slice(0, 5).forEach(post => {
                const div = document.createElement("div");
                div.className = "post";
                div.innerHTML = `
                    <h3>${post.title}</h3>
                    <p>${post.body}</p>
                `;
                postsContainer.appendChild(div);
            });

        } catch (error) {
            displayError(postsContainer, error.message);
        }
    }

    async function loadTodos() {
        try {
            const todos = await fetchData(TODOS_URL);

            todos.slice(0, 5).forEach(todo => {
                const div = document.createElement("div");
                div.className = "todo";
                div.innerHTML = `
                    <p>
                        <strong>${todo.title}</strong> - 
${todo.completed ? "Completed" : "Not Completed"}
                    </p>
                `;
                todosContainer.appendChild(div);
            });

        } catch (error) {
            displayError(todosContainer, error.message);
        }
    }

    function displayError(container, message) {
        container.innerHTML = `<p class="error">Error: ${message}</p>`;
    }

    return {
        init: function () {
            loadPosts();
            loadTodos();
        }
    };

})();

App.init();