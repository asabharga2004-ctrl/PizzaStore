// 2️⃣ Implement Class
var ContactManager = /** @class */ (function () {
    function ContactManager() {
        this.contacts = [];
    }
    // Add Contact
    ContactManager.prototype.addContact = function (contact) {
        var exists = this.contacts.find(function (c) { return c.id === contact.id; });
        if (exists) {
            console.log("\u274C Contact with ID ".concat(contact.id, " already exists."));
            return;
        }
        this.contacts.push(contact);
        console.log("\u2705 Contact \"".concat(contact.name, "\" added successfully."));
    };
    // View Contacts
    ContactManager.prototype.viewContacts = function () {
        if (this.contacts.length === 0) {
            console.log("📭 No contacts available.");
        }
        return this.contacts;
    };
    // Modify Contact
    ContactManager.prototype.modifyContact = function (id, updatedContact) {
        var contact = this.contacts.find(function (c) { return c.id === id; });
        if (!contact) {
            console.log("\u274C Contact with ID ".concat(id, " not found."));
            return;
        }
        Object.assign(contact, updatedContact);
        console.log("\u2705 Contact with ID ".concat(id, " updated successfully."));
    };
    // Delete Contact
    ContactManager.prototype.deleteContact = function (id) {
        var index = this.contacts.findIndex(function (c) { return c.id === id; });
        if (index === -1) {
            console.log("\u274C Contact with ID ".concat(id, " not found."));
            return;
        }
        var deleted = this.contacts.splice(index, 1);
        console.log("\u2705 Contact \"".concat(deleted[0].name, "\" deleted successfully."));
    };
    return ContactManager;
}());
// 3️⃣ Testing Script
var manager = new ContactManager();
// Add Contacts
manager.addContact({
    id: 1,
    name: "Alice",
    email: "alice@example.com",
    phone: "1234567890"
});
manager.addContact({
    id: 2,
    name: "Bob",
    email: "bob@example.com",
    phone: "9876543210"
});
// View Contacts
console.log("\n📋 Contact List:");
console.log(manager.viewContacts());
// Modify Contact
manager.modifyContact(1, { phone: "1111111111" });
// View After Modify
console.log("\n📋 After Modification:");
console.log(manager.viewContacts());
// Delete Contact
manager.deleteContact(2);
// View After Delete
console.log("\n📋 After Deletion:");
console.log(manager.viewContacts());
// Error Case
manager.deleteContact(99);
