// 1️⃣ Define Interface
interface Contact {
  id: number;
  name: string;
  email: string;
  phone: string;
}

// 2️⃣ Implement Class
class ContactManager {
  private contacts: Contact[] = [];

  // Add Contact
  addContact(contact: Contact): void {
    const exists = this.contacts.find(c => c.id === contact.id);
    if (exists) {
      console.log(`❌ Contact with ID ${contact.id} already exists.`);
      return;
    }

    this.contacts.push(contact);
    console.log(`✅ Contact "${contact.name}" added successfully.`);
  }

  // View Contacts
  viewContacts(): Contact[] {
    if (this.contacts.length === 0) {
      console.log("📭 No contacts available.");
    }
    return this.contacts;
  }

  // Modify Contact
  modifyContact(id: number, updatedContact: Partial<Contact>): void {
    const contact = this.contacts.find(c => c.id === id);

    if (!contact) {
      console.log(`❌ Contact with ID ${id} not found.`);
      return;
    }

    Object.assign(contact, updatedContact);
    console.log(`✅ Contact with ID ${id} updated successfully.`);
  }

  // Delete Contact
  deleteContact(id: number): void {
    const index = this.contacts.findIndex(c => c.id === id);

    if (index === -1) {
      console.log(`❌ Contact with ID ${id} not found.`);
      return;
    }

    const deleted = this.contacts.splice(index, 1);
    console.log(`✅ Contact "${deleted[0].name}" deleted successfully.`);
  }
}

// 3️⃣ Testing Script

const manager = new ContactManager();

// Add Contacts
manager.addContact({
  id: 1,
  name: "Alice",
  email: "alice@example.com",
  phone: "1234567890"
});

manager.addContact({
  id: 2,
  name: "Bob",
  email: "bob@example.com",
  phone: "9876543210"
});

// View Contacts
console.log("\n📋 Contact List:");
console.log(manager.viewContacts());

// Modify Contact
manager.modifyContact(1, { phone: "1111111111" });

// View After Modify
console.log("\n📋 After Modification:");
console.log(manager.viewContacts());

// Delete Contact
manager.deleteContact(2);

// View After Delete
console.log("\n📋 After Deletion:");
console.log(manager.viewContacts());

// Error Case
manager.deleteContact(99);