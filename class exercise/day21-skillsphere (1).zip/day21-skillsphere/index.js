const express = require('express');
const path = require('path');

const app = express();
const PORT = 3000;


app.use((req, res, next) => {
  const timestamp = new Date().toISOString();
  console.log(`[${req.method}] ${req.url} at ${timestamp}`);
  next();
});


app.use(express.json());
app.use(express.urlencoded({ extended: true }));


app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));


const courses = [
  { id: 1, title: 'Node.js Fundamentals',    instructor: 'Alice Johnson', duration: '6 hrs',  level: 'Beginner'     },
  { id: 2, title: 'Express Middleware Deep Dive', instructor: 'Bob Smith',  duration: '4 hrs',  level: 'Intermediate' },
  { id: 3, title: 'EJS Templating Mastery', instructor: 'Carol White',  duration: '3 hrs',  level: 'Intermediate' },
  { id: 4, title: 'REST API Design',         instructor: 'David Lee',   duration: '8 hrs',  level: 'Advanced'     },
  { id: 5, title: 'Full Stack JavaScript',   instructor: 'Eve Martinez', duration: '12 hrs', level: 'Advanced'     },
];

const users = [];


app.get('/courses', (req, res) => {
  res.json({ message: 'Courses fetched successfully', data: courses });
});

app.get('/courses/view', (req, res) => {
  res.render('courses', { courses, title: 'SkillSphere — Available Courses' });
});
app.post('/users', (req, res) => {
  const { name, email, role } = req.body;

  if (!name || !email) {
    return res.status(400).json({ message: 'Name and email are required' });
  }

  const newUser = {
    id: users.length + 1,
    name,
    email,
    role: role || 'student',
    createdAt: new Date().toISOString(),
  };

  users.push(newUser);
  res.status(201).json({ message: 'User created successfully', data: newUser });
});


app.get('/users', (req, res) => {
  res.json({ message: 'Users fetched successfully', data: users });
});


app.get('/', (req, res) => {
  res.json({
    message: 'Welcome to SkillSphere LMS API — Day 21',
    endpoints: {
      'GET  /courses':       'List all courses (JSON)',
      'GET  /courses/view':  'View courses page (HTML via EJS)',
      'POST /users':         'Create a new user (JSON body)',
      'GET  /users':         'List all users',
    },
  });
});


app.listen(PORT, () => {
  console.log(`\n🚀 SkillSphere LMS running at http://localhost:${PORT}`);
  console.log(`📘 Courses view : http://localhost:${PORT}/courses/view`);
  console.log(`📡 Courses API  : http://localhost:${PORT}/courses`);
  console.log(`👤 Users API    : http://localhost:${PORT}/users\n`);
});
