# Day 21 — Middleware & Templates (SkillSphere LMS)

## Project Structure

```
day21-skillsphere/
├── index.js           ← Main Express app (all 3 challenges)
├── views/
│   └── courses.ejs    ← EJS template (Challenge 3)
├── package.json
└── README.md
```

---

## ▶️ Commands to Run

### 1. Install dependencies
```bash
npm install
```

### 2. Start the server
```bash
node index.js
```

### 3. (Optional) Start with auto-reload
```bash
npm run dev
```

---

## 🧪 Test the Endpoints

### Challenge 1 — Logging Middleware
Just open any URL — you'll see logs in the terminal:
```
[GET] /courses at 2025-11-07T11:00:00.000Z
```

### Challenge 2 — POST /users (JSON body parsing)
```bash
curl -X POST http://localhost:3000/users \
  -H "Content-Type: application/json" \
  -d '{"name":"John Doe","email":"john@example.com","role":"student"}'
```
**Expected output:**
```json
{ "message": "User created successfully", "data": { "id": 1, "name": "John Doe", ... } }
```

### Challenge 3 — EJS Dynamic Template
Open in browser:
```
http://localhost:3000/courses/view
```

### Other Endpoints
| Method | URL             | Description              |
|--------|-----------------|--------------------------|
| GET    | /               | API welcome + route list |
| GET    | /courses        | All courses (JSON)       |
| GET    | /courses/view   | Courses HTML page (EJS)  |
| POST   | /users          | Create user              |
| GET    | /users          | List all users           |

---

## Challenges Covered

| # | Challenge | Concept |
|---|-----------|---------|
| 1 | Logging Middleware | `app.use()` global middleware |
| 2 | Built-in Middleware | `express.json()`, `express.urlencoded()` |
| 3 | Dynamic Templates | EJS view engine + `res.render()` |
