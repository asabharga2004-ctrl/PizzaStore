

const express = require('express');
const courseRoutes = require('./routes/courses');

const app = express();
const PORT = 4000;


app.use(express.json());


app.get('/', (req, res) => {
  res.send('Welcome to SkillSphere LMS API');
});


app.use('/courses', courseRoutes);


app.listen(PORT, () => {
  console.log(`SkillSphere LMS API running at http://localhost:${PORT}`);
});
