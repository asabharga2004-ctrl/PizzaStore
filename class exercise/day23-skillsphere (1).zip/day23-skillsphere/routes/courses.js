const express        = require('express');
const router         = express.Router();
const validateCourse = require('../middleware/validateCourse');

// ─────────────────────────────────────────────────────────────
// In-Memory Course List (Challenge 1)
// ─────────────────────────────────────────────────────────────
let courses = [
  { id: 1, name: 'Node.js Fundamentals',      duration: '6 hrs',  instructor: 'Alice Johnson', level: 'Beginner'     },
  { id: 2, name: 'Express Middleware',         duration: '4 hrs',  instructor: 'Bob Smith',     level: 'Intermediate' },
  { id: 3, name: 'MongoDB with Mongoose',      duration: '5 hrs',  instructor: 'Carol White',   level: 'Intermediate' },
  { id: 4, name: 'REST API Design',            duration: '8 hrs',  instructor: 'David Lee',     level: 'Advanced'     },
];

let nextId = 5;

// ─────────────────────────────────────────────────────────────
// GET /api/v1/courses — Fetch all courses
// ─────────────────────────────────────────────────────────────
router.get('/', (req, res) => {
  res.status(200).json({
    message: 'Courses fetched successfully',
    total: courses.length,
    data: courses,
  });
});

// ─────────────────────────────────────────────────────────────
// GET /api/v1/courses/:id — Fetch single course
// ─────────────────────────────────────────────────────────────
router.get('/:id', (req, res) => {
  const course = courses.find(c => c.id === parseInt(req.params.id));
  if (!course) {
    return res.status(404).json({ error: `Course with id ${req.params.id} not found` });
  }
  res.status(200).json({ message: 'Course fetched successfully', data: course });
});

// ─────────────────────────────────────────────────────────────
// POST /api/v1/courses — Create new course (with validation)
// Challenge 2: validateCourse middleware runs first
// ─────────────────────────────────────────────────────────────
router.post('/', validateCourse, (req, res) => {
  const { name, duration, instructor, level } = req.body;

  const newCourse = {
    id: nextId++,
    name,
    duration,
    instructor: instructor || 'TBD',
    level: level || 'Beginner',
  };

  courses.push(newCourse);
  console.log(`✅ Course created: ${newCourse.name}`);

  res.status(201).json({
    message: 'Course created successfully',
    data: newCourse,
  });
});

// ─────────────────────────────────────────────────────────────
// PUT /api/v1/courses/:id — Update existing course
// ─────────────────────────────────────────────────────────────
router.put('/:id', validateCourse, (req, res) => {
  const index = courses.findIndex(c => c.id === parseInt(req.params.id));
  if (index === -1) {
    return res.status(404).json({ error: `Course with id ${req.params.id} not found` });
  }

  const { name, duration, instructor, level } = req.body;
  courses[index] = {
    ...courses[index],
    name:       name       || courses[index].name,
    duration:   duration   || courses[index].duration,
    instructor: instructor || courses[index].instructor,
    level:      level      || courses[index].level,
  };

  console.log(`✏️  Course updated: id ${req.params.id}`);
  res.status(200).json({
    message: 'Course updated successfully',
    data: courses[index],
  });
});

// ─────────────────────────────────────────────────────────────
// DELETE /api/v1/courses/:id — Delete a course
// ─────────────────────────────────────────────────────────────
router.delete('/:id', (req, res) => {
  const index = courses.findIndex(c => c.id === parseInt(req.params.id));
  if (index === -1) {
    return res.status(404).json({ error: `Course with id ${req.params.id} not found` });
  }

  const deleted = courses.splice(index, 1);
  console.log(`🗑️  Course deleted: id ${req.params.id}`);

  res.status(200).json({
    message: 'Course deleted successfully',
    data: deleted[0],
  });
});

module.exports = router;
