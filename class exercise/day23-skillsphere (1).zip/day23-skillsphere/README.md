# Day 23 — RESTful APIs & API Middleware (SkillSphere LMS)

## Project Structure

```
day23-skillsphere/
├── index.js                      ← Main Express app
├── routes/
│   └── courses.js                ← CRUD routes (Challenge 1)
├── middleware/
│   ├── validateCourse.js         ← Input validation (Challenge 2)
│   ├── rateLimiter.js            ← Rate limiting (Challenge 3)
│   └── errorHandler.js           ← Centralized error handler
└── package.json
```

---

## ▶️ Commands to Run

### Step 1 — Install dependencies
```bash
npm install
```

### Step 2 — Start server
```bash
node index.js
```

---

## 🧪 Test All 3 Challenges in Postman

### Challenge 1 — CRUD Operations

**GET all courses:**
```
Method → GET
URL    → http://localhost:3000/api/v1/courses
```

**GET single course:**
```
Method → GET
URL    → http://localhost:3000/api/v1/courses/1
```

**POST create course:**
```
Method → POST
URL    → http://localhost:3000/api/v1/courses
Body   → raw → JSON:
{
  "name": "React for Beginners",
  "duration": "5 hrs",
  "instructor": "Eve Martinez",
  "level": "Beginner"
}
```

**PUT update course:**
```
Method → PUT
URL    → http://localhost:3000/api/v1/courses/1
Body   → raw → JSON:
{
  "name": "Node.js Advanced",
  "duration": "10 hrs",
  "instructor": "Alice Johnson",
  "level": "Advanced"
}
```

**DELETE course:**
```
Method → DELETE
URL    → http://localhost:3000/api/v1/courses/1
```

---

### Challenge 2 — Input Validation

**Send empty name to trigger error:**
```
Method → POST
URL    → http://localhost:3000/api/v1/courses
Body   → raw → JSON:
{
  "name": "",
  "duration": ""
}
Expected → { "error": "Course name is required" }
```

---

### Challenge 3 — Rate Limiting

```
Send the same GET request 6 times quickly in Postman
After 5th request →
{ "error": "Too many requests" }
```

---

## 📸 Screenshots Needed

| # | What | How |
|---|------|-----|
| 1 | GET all courses | Postman GET /api/v1/courses |
| 2 | POST create course | Postman POST with JSON body |
| 3 | Validation error | POST with empty name field |
| 4 | Rate limit error | Send 6 requests quickly |
| 5 | DELETE course | Postman DELETE /api/v1/courses/1 |
| 6 | Terminal logs | All requests showing in terminal |
