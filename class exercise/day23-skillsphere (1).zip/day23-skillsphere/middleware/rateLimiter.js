const rateLimit = require('express-rate-limit');

// Challenge 3: Restrict to 5 requests per minute
const apiLimiter = rateLimit({
  windowMs: 1 * 60 * 1000, // 1 minute
  max: 5,                   // max 5 requests per window
  standardHeaders: true,
  legacyHeaders: false,
  handler: (req, res) => {
    res.status(429).json({ error: 'Too many requests' }); // Expected Outcome
  },
});

module.exports = apiLimiter;
