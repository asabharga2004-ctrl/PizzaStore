const { body, validationResult } = require('express-validator');

// Challenge 2: Validate course name and duration are required
const validateCourse = [
  body('name')
    .notEmpty().withMessage('Course name is required')
    .isString().withMessage('Course name must be a string')
    .trim(),

  body('duration')
    .notEmpty().withMessage('Duration is required')
    .isString().withMessage('Duration must be a string')
    .trim(),

  body('instructor')
    .optional()
    .isString().withMessage('Instructor must be a string')
    .trim(),

  body('level')
    .optional()
    .isIn(['Beginner', 'Intermediate', 'Advanced'])
    .withMessage('Level must be Beginner, Intermediate, or Advanced'),

  // Check result and return errors
  (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      // Return first error message (matches expected outcome)
      return res.status(400).json({ error: errors.array()[0].msg });
    }
    next();
  },
];

module.exports = validateCourse;
