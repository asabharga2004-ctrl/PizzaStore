const express      = require('express');
const apiLimiter   = require('./middleware/rateLimiter');
const errorHandler = require('./middleware/errorHandler');
const coursesRouter = require('./routes/courses');

const app  = express();
const PORT = 3000;

// ─────────────────────────────────────────────────────────────
// Built-in Middleware
// ─────────────────────────────────────────────────────────────
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// ─────────────────────────────────────────────────────────────
// Logging Middleware
// ─────────────────────────────────────────────────────────────
app.use((req, res, next) => {
  console.log(`[${req.method}] ${req.url} at ${new Date().toISOString()}`);
  next();
});

// ─────────────────────────────────────────────────────────────
// Challenge 3: Rate Limiting — applied to all /api routes
// Restricts to 5 requests per minute
// ─────────────────────────────────────────────────────────────
app.use('/api/', apiLimiter);

// ─────────────────────────────────────────────────────────────
// Challenge 1: CRUD Routes — versioned as /api/v1 (Best Practice)
// ─────────────────────────────────────────────────────────────
app.use('/api/v1/courses', coursesRouter);

// ─────────────────────────────────────────────────────────────
// Root
// ─────────────────────────────────────────────────────────────
app.get('/', (req, res) => {
  res.json({
    message: '🎓 SkillSphere LMS API — Day 23',
    version: 'v1',
    endpoints: {
      'GET    /api/v1/courses'      : 'Get all courses',
      'GET    /api/v1/courses/:id'  : 'Get course by ID',
      'POST   /api/v1/courses'      : 'Create new course (validated)',
      'PUT    /api/v1/courses/:id'  : 'Update course (validated)',
      'DELETE /api/v1/courses/:id'  : 'Delete course',
    },
    rateLimit: '5 requests per minute per IP',
  });
});

// ─────────────────────────────────────────────────────────────
// 404 Handler
// ─────────────────────────────────────────────────────────────
app.use((req, res) => {
  res.status(404).json({ error: `Route ${req.url} not found` });
});

// ─────────────────────────────────────────────────────────────
// Centralized Error Handler (Best Practice)
// ─────────────────────────────────────────────────────────────
app.use(errorHandler);

// ─────────────────────────────────────────────────────────────
// Start Server
// ─────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`\n🚀 SkillSphere LMS running at http://localhost:${PORT}`);
  console.log(`📡 Courses API  : http://localhost:${PORT}/api/v1/courses`);
  console.log(`⚡ Rate Limit   : 5 requests/minute\n`);
});
