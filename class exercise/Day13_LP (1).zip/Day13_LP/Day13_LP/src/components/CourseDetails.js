import React from 'react';

export default function CourseDetails({ course }) {
  return (
    <div style={{
      border: '1px solid rgba(180, 83, 9, 0.3)',
      background: 'rgba(180, 83, 9, 0.05)',
      padding: 16,
      borderRadius: 10,
      marginTop: 12
    }}>
      <h3 style={{ margin: '0 0 8px', color: 'var(--accent)', fontSize: 15 }}>
        {course.title}
      </h3>
      <p style={{ margin: '4px 0', fontSize: 13, color: 'var(--muted)' }}>
        Course ID: {course.id}
      </p>
      <p style={{ margin: '4px 0', fontSize: 13, color: 'var(--muted)' }}>
        This component was loaded lazily when you clicked View Details.
      </p>
    </div>
  );
}
