import React from 'react';

export default function BrokenProduct({ crash }) {
  if (crash) throw new Error('BrokenProduct crashed while rendering');

  return (
    <div style={{
      border: '1px solid rgba(180, 83, 9, 0.25)',
      background: 'rgba(180, 83, 9, 0.05)',
      padding: 14,
      borderRadius: 10,
      marginTop: 14
    }}>
      <h4 style={{ margin: '0 0 6px', color: 'var(--accent)', fontSize: 15 }}>
        Product Card
      </h4>
      <p style={{ margin: 0, fontSize: 14, color: 'var(--muted)' }}>
        This product card is safe. Toggle the crash to simulate an error.
      </p>
    </div>
  );
}
