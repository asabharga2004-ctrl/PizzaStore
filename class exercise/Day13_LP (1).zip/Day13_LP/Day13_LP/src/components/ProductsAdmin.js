import React, { useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { fetchProducts, updateProduct } from '../features/products/productsSlice';

export default function ProductsAdmin() {
  const dispatch = useDispatch();
  const products = useSelector(s => s.products.items);
  const status   = useSelector(s => s.products.status);

  useEffect(() => {
    dispatch(fetchProducts());
  }, [dispatch]);

  function increasePrice(p) {
    dispatch(updateProduct({ ...p, price: p.price + 1 }));
  }

  return (
    <div className="card products-admin">
      <h3>Products Admin</h3>
      {status === 'loading' && (
        <p style={{ color: 'var(--muted)', fontSize: 13 }}>Loading...</p>
      )}
      <ul>
        {products.map(p => (
          <li key={p.id}>
            <span>
              {p.name}
              <span style={{ color: 'var(--accent-2)', marginLeft: 8, fontWeight: 700 }}>
                ${p.price}
              </span>
            </span>
            <button className="btn-warning" onClick={() => increasePrice(p)}>
              Increase $
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}
