import React from 'react';

export default function InstructorProfile({ id }) {
  return (
    <div className="instructor">
      <h3 style={{ margin: '0 0 8px', color: 'var(--accent)', fontSize: 15 }}>
        Instructor #{id}
      </h3>
      <p style={{ margin: '3px 0', fontSize: 13 }}>Name: Jane Doe</p>
      <p style={{ margin: '3px 0', fontSize: 13 }}>Bio: Experienced React instructor.</p>
      <p style={{ margin: '8px 0 0', fontSize: 12, color: 'var(--muted)' }}>
        This profile is code-split and loaded via React.lazy.
      </p>
    </div>
  );
}
