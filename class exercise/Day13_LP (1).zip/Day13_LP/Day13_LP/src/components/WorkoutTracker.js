import React, { useState } from 'react';
import useTimer from '../hooks/useTimer';

export default function WorkoutTracker() {
  const [sets,    setSets]    = useState(0);
  const [resting, setResting] = useState(false);
  const { seconds, start, stop, reset } = useTimer(0, false);

  function completeSet() {
    setSets(s => s + 1);
    reset(0);
    start();
    setResting(true);
    setTimeout(() => {
      stop();
      setResting(false);
      reset(0);
    }, 30000);
  }

  function handleReset() {
    setSets(0);
    reset(0);
    stop();
    setResting(false);
  }

  return (
    <div className="card workout-card">
      <h3>Workout Tracker</h3>
      <p className="small" style={{ marginBottom: 4 }}>
        <span style={{ color: 'var(--muted)' }}>Sets completed: </span>
        <strong style={{ fontSize: 18, color: 'var(--accent)' }}>{sets}</strong>
      </p>
      <p style={{ margin: '6px 0 14px' }}>
        {resting ? (
          <span className="timer-badge">Resting - {seconds}s / 30s</span>
        ) : (
          <span style={{ color: '#15803d', fontWeight: 700 }}>Ready</span>
        )}
      </p>
      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
        <button className="btn-success" onClick={completeSet}>
          Complete Set (start 30s rest)
        </button>
        <button className="secondary" onClick={handleReset}>
          Reset
        </button>
      </div>
    </div>
  );
}
