import React from 'react';

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, info) {
    console.error('ErrorBoundary caught:', error, info);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="error-box">
          <h3 style={{ margin: '0 0 6px', fontSize: 15 }}>Something went wrong.</h3>
          <p style={{ margin: 0, fontSize: 13 }}>
            Showing a fallback UI instead of crashing the app.
          </p>
        </div>
      );
    }
    return this.props.children;
  }
}

export default ErrorBoundary;
