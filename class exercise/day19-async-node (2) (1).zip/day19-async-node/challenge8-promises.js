

const fs = require('fs').promises;
const path = require('path');

const inputPath  = path.join(__dirname, 'files', 'input.txt');
const outputPath = path.join(__dirname, 'files', 'output.txt');

console.log('Starting Promise-based file copy...\n');

fs.readFile(inputPath, 'utf8')
  .then((data) => {
    console.log('📄 Read from input.txt:');
    console.log(data);
    // Pass data forward to the next .then()
    return fs.writeFile(outputPath, data, 'utf8');
  })
  .then(() => {
    console.log('✅ File copied successfully!');
    console.log(`Output saved to: files/output.txt`);
  })
  // BONUS: Error handling with .catch()
  .catch((err) => {
    console.error('❌ Error during file operation:', err.message);
  });
