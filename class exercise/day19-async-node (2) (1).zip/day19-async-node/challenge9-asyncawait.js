

const fs = require('fs').promises;
const path = require('path');

const inputPath  = path.join(__dirname, 'files', 'input.txt');
const outputPath = path.join(__dirname, 'files', 'output.txt');


function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}


async function copyFile() {
  try {
    console.log('Starting Async/Await file copy...\n');

   
    const data = await fs.readFile(inputPath, 'utf8');
    console.log('📄 Read from input.txt:');
    console.log(data);

    
    console.log('⏳ Simulating slow operation (1 second delay)...');
    await delay(1000);

    
    await fs.writeFile(outputPath, data, 'utf8');

    
    console.log('✅ File copied successfully!');
    console.log(`Output saved to: files/output.txt`);

  } catch (err) {
    
    console.error('❌ Error:', err.message);
  }
}

copyFile();
