

const fs = require('fs');
const path = require('path');

const filePath = path.join(__dirname, 'files', 'data.txt');

console.log('Starting file read (non-blocking)...');


fs.readFile(filePath, 'utf8', (err, data) => {
  if (err) {
    console.error('Error reading file:', err.message);
    return;
  }

  console.log('\n📄 File Contents:');
  console.log(data);

 
  setTimeout(() => {
    console.log('✅ Read operation completed');
  }, 1500); 
});


console.log('👉 This line runs BEFORE the file read completes (async behavior!)');
